package com.example.listapplications;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class ServerConnection {
    //protected String postPermissions;
    private String postBodyString;
    private String[] permissionList;
    private MediaType mediaType;
    private RequestBody requestBody,requestBody1;

    protected RequestBody buildRequestBody(String msg){
        postBodyString = msg;
//        mediaType = MediaType.parse("text/plain");
//        requestBody = RequestBody.create(postBodyString, mediaType);
//
//        requestBody1 = new MultipartBody.Builder()
//                .setType(MultipartBody.
//                .addFormDataPart("perm_list", postBodyString)
//                .build();
//        return requestBody1;

    requestBody = new FormBody.Builder().add("perm_list", postBodyString).build();
    return requestBody;

    }


}
